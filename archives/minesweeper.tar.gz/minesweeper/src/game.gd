extends Node2D

# 扫雷游戏主脚本

@export var grid_width: int = 10
@export var grid_height: int = 10
@export var mine_count: int = 15

var cell_scene = preload("res://scenes/cell.tscn")
var cells: Array = []
var game_over: bool = false
var first_click: bool = true

@onready var grid_container = $GridContainer
@onready var mine_label = $UI/MineLabel
@onready var status_label = $UI/StatusLabel
@onready var restart_button = $UI/RestartButton

func _ready():
	restart_button.pressed.connect(_on_restart)
	initialize_game()

func initialize_game():
	game_over = false
	first_click = true
	cells.clear()
	
	# 清除现有格子
	for child in grid_container.get_children():
		child.queue_free()
	
	# 设置网格容器
	grid_container.columns = grid_width
	
	# 创建格子
	for y in range(grid_height):
		var row = []
		for x in range(grid_width):
			var cell = cell_scene.instantiate()
			cell.grid_x = x
			cell.grid_y = y
			cell.cell_revealed.connect(_on_cell_revealed)
			cell.cell_flagged.connect(_on_cell_flagged)
			grid_container.add_child(cell)
			row.append(cell)
		cells.append(row)
	
	update_mine_label()
	status_label.text = "点击格子开始游戏"

func place_mines(exclude_x: int, exclude_y: int):
	var mines_placed = 0
	while mines_placed < mine_count:
		var x = randi() % grid_width
		var y = randi() % grid_height
		
		# 避免在第一次点击的位置放置地雷
		if x == exclude_x and y == exclude_y:
			continue
		
		var cell = cells[y][x]
		if not cell.is_mine:
			cell.is_mine = true
			mines_placed += 1
	
	# 计算每个格子周围的地雷数
	for y in range(grid_height):
		for x in range(grid_width):
			if not cells[y][x].is_mine:
				cells[y][x].neighbor_mines = count_neighbor_mines(x, y)

func count_neighbor_mines(x: int, y: int) -> int:
	var count = 0
	for dy in range(-1, 2):
		for dx in range(-1, 2):
			if dx == 0 and dy == 0:
				continue
			var nx = x + dx
			var ny = y + dy
			if nx >= 0 and nx < grid_width and ny >= 0 and ny < grid_height:
				if cells[ny][nx].is_mine:
					count += 1
	return count

func _on_cell_revealed(x: int, y: int):
	if game_over:
		return
	
	var cell = cells[y][x]
	
	# 第一次点击时放置地雷
	if first_click:
		first_click = false
		place_mines(x, y)
	
	# 如果点击到地雷，游戏结束
	if cell.is_mine:
		game_over = true
		reveal_all_mines()
		status_label.text = "游戏结束！你踩到地雷了！"
		return
	
	# 如果周围没有地雷，自动揭开相邻格子
	if cell.neighbor_mines == 0:
		reveal_empty_cells(x, y)
	
	# 检查是否获胜
	check_win()

func reveal_empty_cells(x: int, y: int):
	for dy in range(-1, 2):
		for dx in range(-1, 2):
			if dx == 0 and dy == 0:
				continue
			var nx = x + dx
			var ny = y + dy
			if nx >= 0 and nx < grid_width and ny >= 0 and ny < grid_height:
				var neighbor = cells[ny][nx]
				if not neighbor.is_revealed and not neighbor.is_flagged:
					neighbor.reveal()
					if neighbor.neighbor_mines == 0:
						reveal_empty_cells(nx, ny)

func _on_cell_flagged():
	update_mine_label()

func update_mine_label():
	var flagged_count = 0
	for row in cells:
		for cell in row:
			if cell.is_flagged:
				flagged_count += 1
	var remaining = mine_count - flagged_count
	mine_label.text = "剩余地雷: %d" % remaining

func reveal_all_mines():
	for row in cells:
		for cell in row:
			if cell.is_mine:
				cell.reveal()

func check_win():
	var revealed_count = 0
	for row in cells:
		for cell in row:
			if cell.is_revealed:
				revealed_count += 1
	
	var total_cells = grid_width * grid_height
	if revealed_count == total_cells - mine_count:
		game_over = true
		status_label.text = "恭喜你！你赢了！"

func _on_restart():
	initialize_game()
